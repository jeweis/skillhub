---
name: Prompt QA Kit
description: Use when evaluating prompt regressions and reviewing expectation drift.
---

# Prompt QA Kit

Use this skill to compare prompts, assertions, and regression output.
